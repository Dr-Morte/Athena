package database;

public class DataBase 
{
	public void updateTable()
	{
		for(int i=0;i<ctx.getChildCount())
		{
			if(ctx.getChild(i)==)
		}

	}
}

