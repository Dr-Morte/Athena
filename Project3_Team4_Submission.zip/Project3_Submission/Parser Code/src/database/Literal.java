package database;

public class Literal implements Comparable<Literal>{

	public Literal(String str){}

	@Override
	public int compareTo(Literal arg0) {
		return 0;
	}
}
