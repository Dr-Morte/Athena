package database;

import java.util.*;
import java.util.function.Predicate;

import parser.Relation;
public class Relation {
	
	public int numAttributes;
	public int numTuples;
	
	public ArrayList<Attribute> attributeList;
	public ArrayList<ArrayList<String>> dataMembers;
	
	public Relation() {
		this.numAttributes = 0;
		this.numTuples = 0;
		this.attributeList = new ArrayList<Attribute>();
		this.dataMembers = new ArrayList<ArrayList<String>>();
	}
	// Used when making table in the main, takes in number of tuples
	public Relation(int numTup){
		this.numAttributes = 0;
		this.numTuples = numTup;
		this.attributeList = new ArrayList<Attribute>();
		this.dataMembers = new ArrayList<ArrayList<String>>();
	}
	// Copy constructor
	public Relation(Relation t) {
		this.numAttributes = t.numAttributes;
		this.numTuples = t.numTuples;
		this.attributeList = t.attributeList;
		this.dataMembers = t.dataMembers;
	}
	// prints a tuple
	public void printTuple(int x){
		for(int i = 0; i < attributeList.size(); i++){
			System.out.print(dataMembers.get(i).get(x) + " ");
		}
		System.out.println();
	}
	public void printTable(){
		for(int i = 0; i < numAttributes; i++){
			System.out.print(this.attributeList.get(i).getName() + " ");
		}
		System.out.println();
		for(int i = 0; i < numTuples; i++){
			this.printTuple(i);
		}
		System.out.println();
	}
	// change an existing attribute
	public void updateAttribute(int pos, String att){
		this.attributeList.get(pos).setName(att);
	}
	// creates a new attribute and respective column
	public void addAttribute(String att){
		numAttributes = numAttributes + 1;
		
		attributeList.add(new Attribute());
		
		attributeList.get(attributeList.size()-1).setName(att);
		
		dataMembers.add(new ArrayList<String>());
		for(int i = 0; i < numTuples; i++){
			dataMembers.get(attributeList.size()-1).add("Empty");
		}
	}
	// assigns STRING data to existing data position
	public void setData(int column, int row, String data){
		dataMembers.get(column).set(row, data);
	}
	
	// Creates a new Unfilled tuple
	public void addTuple(){
		this.numTuples = numTuples + 1;
		for(int i = 0; i < numAttributes; i++){
			this.dataMembers.get(i).add("Empty");
		}
	}
	
	public ArrayList<String> getTuple(int pos) {
		ArrayList<String> newRow = new ArrayList<String>();
		for(int i = 0; i < numAttributes; ++i) {
			newRow.add(dataMembers.get(i).get(pos));
		}
		return newRow;
	}
	
	public void mergeTuples(Relation relation, int rowOne, int rowTwo){
		boolean found;
		for(int i = 0; i < relation.attributeList.size(); i++){
			found = false;
			for(int j = 0; j < numAttributes; j++){
				if(relation.attributeList.get(i).getName().equals(attributeList.get(j).getName())){
					setData(j, rowOne, relation.dataMembers.get(i).get(rowTwo));
					found = true;
				}
			}
			if(!found){
				addAttribute(relation.attributeList.get(i).getName(), relation.attributeList.get(i).getType());
				setData(numAttributes - 1, rowOne, relation.dataMembers.get(i).get(rowTwo));
			}
		}
	}
	
	// Imports a tuple from an existing table
	public void importTuple(Relation relation, int rowNum){
		this.addTuple();
		boolean found;
		for(int i = 0; i < relation.attributeList.size(); i++){
			found = false;
			for(int j = 0; j < numAttributes; j++){
				if(relation.attributeList.get(i).getName().equals(attributeList.get(j).getName())){
					setData(j, numTuples -1, relation.dataMembers.get(i).get(rowNum));
					found = true;
				}
			}
			if(!found){
				addAttribute(relation.attributeList.get(i).getName(), relation.attributeList.get(i).getType());
				setData(numAttributes - 1, numTuples -1, relation.dataMembers.get(i).get(rowNum));
			}
		}
	}
	// Returns a Table of tuples with a common condition
	public Relation selection(String condition) {
		Relation newTable = new Relation();
		for(int i = 0; i < numTuples; i++) {
			for(int j = 0; j < numAttributes; j++) {
				if(dataMembers.get(j).get(i).equals(condition)) {
					newTable.importTuple(this, i);
				}
			}
		}
		return newTable;
	}
	
	public ArrayList<String> projection(String attribute) {
		ArrayList<String> list = new ArrayList<String>();
		for(int i = 0; i < numAttributes; i++) {
			if(attributeList.get(i).getName().equals(attribute)){
				for(int j = 0; j < numTuples; ++j) {
					list.add(dataMembers.get(i).get(j));
				}
			}
		}
		return list;
	}
	
	// Calculates the Union of two relations and returns a new relation
	public static Relation setUnion(Relation tableOne, Relation tableTwo) {
		Relation newTable = new Relation();
		
		for(int i = 0; i < tableOne.numTuples; ++i) {
			newTable.importTuple(tableOne, i);
		}
		
		for(int i = 0; i < tableTwo.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < newTable.numTuples; ++j) {
				if(tableTwo.dataMembers.get(0).get(i).equals(newTable.dataMembers.get(0).get(j))) {
					found = true;
				}
			}
			if (!found) {
				newTable.importTuple(tableTwo, i);
			}
		}
		return newTable;
	}
	
	// Calculates the Difference of two relations and returns a new relation
	public static Relation setDiff(Relation tableOne, Relation tableTwo) {
		Relation newTable = new Relation();
		
		for(int i = 0; i < tableOne.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < tableTwo.numTuples; ++j) {
				if(tableOne.dataMembers.get(0).get(i).equals(tableTwo.dataMembers.get(0).get(j))) {
					found = true;
				}
			}
			if (!found) {
				newTable.importTuple(tableOne, i);
			}
		}
		for(int i = 0; i < tableTwo.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < tableOne.numTuples; ++j) {
				if(tableTwo.dataMembers.get(0).get(i).equals(tableOne.dataMembers.get(0).get(j))) {
					found = true;
				}
			}
			if (!found) {
				newTable.importTuple(tableTwo, i);
			}
		}
		return newTable;
	}
	
	public void naturalJoin(Relation relation) 
	{
		for(int i = 0; i < relation.numTuples; ++i) 
		{
			boolean found = false;
			for(int j = 0; j < numTuples; ++j) 
			{
				if(relation.dataMembers.get(0).get(i).equals(dataMembers.get(0).get(j))) 
				{
					this.mergeTuples(relation, j, i);
					found = true;
				}
			}
			if(!found) 
			{
				importTuple(relation, i);
			}
		}
	}

	private void addTuple(Tuple t)
	{
		
	}
	public Relation selectAllTuples (Predicate<Tuple> predicate)
	{
		String name;
		ArrayList<Tuple> rows;
	
		Relation r = new Relation();
		for (Tuple t : rows)
		{
			if (predicate.test(t))
					r.addTuple(t);
		}
		return r;
	}
}