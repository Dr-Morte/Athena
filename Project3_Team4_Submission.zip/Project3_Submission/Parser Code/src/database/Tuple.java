package database;

import java.util.*;
public class Tuple {
	
	public String name;
	public ArrayList<String> tuple;
	
	public Tuple() {
		this.tuple = new ArrayList<String>();
		this.name = "Empty";
		
	}
	public Tuple(Relation r, int rowNum) {
		this.tuple = new ArrayList<String>();
		tuple = r.getTuple(rowNum);
		this.name = tuple.get(0);
	}
	public String getName() {
		return name;
	}
	public ArrayList<String> getTuple(){
		return tuple;
	}
}