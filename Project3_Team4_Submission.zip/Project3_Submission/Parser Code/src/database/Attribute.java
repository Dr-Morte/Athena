package database;
import java.util.*;
public class Attribute {

	public String name;
	public String type;
	
	public Attribute(){
		this.name = "default";
		this.type = "default_type";
	}
	public Attribute(String name)
	{
		this.name = name;
	}
	public Attribute(Attribute attribute){
		this.name = attribute.name;
	}
	public String getName(){
		return name;
	}
	public String getType(){
		return type;
	}
	public void setName(String newName){
		this.name = newName;
	}
	
}