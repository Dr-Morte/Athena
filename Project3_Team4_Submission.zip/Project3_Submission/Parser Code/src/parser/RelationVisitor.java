package parser;

import java.util.ArrayList;
import java.util.concurrent.locks.Condition;

import database.Attribute;
import database.Relation;
import parser.ggParser.AtomicexprContext;
import parser.ggParser.DifferenceContext;
import parser.ggParser.ExprContext;
import parser.ggParser.NaturaljoinContext;
import parser.ggParser.ProductContext;
import parser.ggParser.ProjectionContext;
import parser.ggParser.RelationnameContext;
import parser.ggParser.RenamingContext;
import parser.ggParser.SelectionContext;
import parser.ggParser.UnionContext;

public class RelationVisitor extends ggBaseVisitor<Relation>{
	
	@Override public Relation visitExpr(ExprContext ctx) {
		
		return visit(ctx.getChild(0));
	}

	@Override public Relation visitAtomicexpr(AtomicexprContext ctx) { 
		
		if(ctx.getChildCount() > 1) {
			 Relation expr = visit(ctx.getChild(1));
			 return expr;
		}else {
			 Relation relationname = ctx.getChild(0).accept(new RelationVisitor());
			 return relationname;
		}
		 
		
	}
	
	@Override public Relation visitSelection(SelectionContext ctx) { 
		
		//condition needs a predicate 
		Condition condition = ctx.getChild(2).accept( new ConditionVisitor());
		Relation atmoic_expr = visit(ctx.getChild(4));
		
		return select(); //function from database team member
		
	}
	
	//projects selects a subset of attributes from a relation
	@Override public Relation visitProjection(ProjectionContext ctx) {
		
		ArrayList<String> attributeList = ctx.getChild(2).accept(new StringlistVisitor());
		Relation atmoic_expr = visit(ctx.getChild(4));
		Relation newRelation = new Relation();
		for(int i = 0;i < attributeList.size(); i++) {
			if (attributeList.at(i).equals(atomic_expr)) 
			{
				newRelation.addTuple();// add list at i in the new relation
			} 
		}
		return newRelation;	
	}

	@Override public Relation visitRenaming(RenamingContext ctx) {
		
		//creates a new relation with the column names containing the tupples and the atomic expression
		ArrayList<String> attributeList = ctx.getChild(2).accept(new StringlistVisitor());
		for(int i = 4;i < list.size(); i+=2)
			ArrayList<String> list = ctx.getChild(i).accept(new StringlistVisitor());
		Relation atmoic_expr = visit(ctx.getChild(4));
		Relation newRelation = new Relation();
		for(int i = 0;i < attributeList.size(); i++) {
			//  attribute [i] in atomic expression replace that with whatever is in list[i].
			if(attributeList.at(i).equals(atomic_expr))
			{
				attributeList.at(i)=list.get(i);
			}
		}
		newRelation.updateAttribute(list); //rename (updateAttribute) function from team member
		return newRelation;
		
	}
	
	
	@Override public Relation visitUnion(UnionContext ctx) {

		Relation relation1 = visit(ctx.getChild(0));
		Relation relation2 = visit(ctx.getChild(2));
		Relation r;
		r.addAttribute(relation1.setUnion(relation2));
		return r;
	}
	
	@Override public Relation visitDifference(DifferenceContext ctx) {
		
		Relation relation1 = visit(ctx.getChild(0));
		Relation relation2 = visit(ctx.getChild(2));
		Relation r;
		r.addAttribute(relation1.setDiff(relation2));
		return r; 
		
	}
	
	@Override public Relation visitProduct(ProductContext ctx) {
		
		Relation relation1 = visit(ctx.getChild(0));
		Relation relation2 = visit(ctx.getChild(2));
		Relation r;
		r.addAttribute(relation1.setProduct(relation2));
		// these are the two realtions passed into the Product fucntions 
		
		return r;
		
	}
	
	@Override public Relation visitNaturaljoin(NaturaljoinContext ctx) { 
		
		Relation relation1 = visit(ctx.getChild(0));
		Relation relation2 = visit(ctx.getChild(2));
		// these are the two realtions passed into the difference fucntions 
		Relation r;
		r.addAttribute(relation1.naturalJoin(relation2));
		
		return r;
		
	}
	
	@Override public Relation visitRelationname(RelationnameContext ctx) {
		// store the name that it gets from identifier 
		// feed the name the map which will return a relation 
		
		String relationname = ctx.getChild(0).accept(new StringVisitor());
		Relation r;
		r.addAttribute(relationname);
		return r;
		
	}
	
	
	
	

}
