// Generated from gg.g4 by ANTLR 4.7
package parser;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ggParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ggVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link ggParser#query}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery(ggParser.QueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#relationname}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelationname(ggParser.RelationnameContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(ggParser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr(ggParser.ExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#atomicexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtomicexpr(ggParser.AtomicexprContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#selection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelection(ggParser.SelectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondition(ggParser.ConditionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#conjunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConjunction(ggParser.ConjunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#comparison}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparison(ggParser.ComparisonContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp(ggParser.OpContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#operand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperand(ggParser.OperandContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#attributename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttributename(ggParser.AttributenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteral(ggParser.LiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#projection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProjection(ggParser.ProjectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#attributelist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttributelist(ggParser.AttributelistContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#renaming}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRenaming(ggParser.RenamingContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#union}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnion(ggParser.UnionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#difference}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDifference(ggParser.DifferenceContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#product}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProduct(ggParser.ProductContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#naturaljoin}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNaturaljoin(ggParser.NaturaljoinContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(ggParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommand(ggParser.CommandContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#opencmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpencmd(ggParser.OpencmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#closecmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClosecmd(ggParser.ClosecmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#writecmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWritecmd(ggParser.WritecmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#exitcmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExitcmd(ggParser.ExitcmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#showcmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShowcmd(ggParser.ShowcmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#createcmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreatecmd(ggParser.CreatecmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#updatecmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdatecmd(ggParser.UpdatecmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#insertcmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsertcmd(ggParser.InsertcmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#deletecmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeletecmd(ggParser.DeletecmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#typedattributelist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypedattributelist(ggParser.TypedattributelistContext ctx);
	/**
	 * Visit a parse tree produced by {@link ggParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(ggParser.TypeContext ctx);
}