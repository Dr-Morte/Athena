package parser;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class gg
{

     public static void main(String[] args)
     { 
    	String FILENAME = "C:\\Users\\eric\\Documents\\DS-5 Workspace\\DBproj\\src\\class_schedule.txt";
    	
    	//can either use scanner or input from given string below
    	//String str = "CREATE TABLE relation (Name VARCHAR(50), Age INTEGER) PRIMARY KEY (Name)"; 
    	//Scanner scanner = new Scanner(System.in); //for using userinput
    	//while(scanner.hasNextLine())
    	{
	      //  String str = scanner.nextLine();
			    	 try
			    	 {
			    	 	BufferedReader br = null;
			    		FileReader fr = null;
			
			    		
			    			fr = new FileReader(FILENAME);
			    			br = new BufferedReader(fr);
			
			    			String sCurrentLine;
			
			    			br = new BufferedReader(new FileReader(FILENAME));
			    			
				        // create a CharStream that reads from standard input
			   			while (!((sCurrentLine = br.readLine()).isEmpty())) 
				    	{
				    			//System.out.println(sCurrentLine);
				    		
				    			ANTLRInputStream input = new ANTLRInputStream(sCurrentLine);//str
				    		
					        
					        // create a lexer that feeds off of input CharStream
					        ggLexer lexer = new ggLexer(input);
					
					        // create a buffer of tokens pulled from the lexer
					        CommonTokenStream tokens = new CommonTokenStream(lexer);
					
					        // create a parser that feeds off the tokens buffer
					        ggParser parser = new ggParser(tokens);
					
					        // begin parsing at rule 'statement' (my root rule)
					        ParseTree tree = parser.program();
					
					        // use my parseTreeVisitor to traverse the parse tree
					        ProgramVisitor ptv = new ProgramVisitor();
					        ptv.visit(tree);
			    		}
		    	 	}
	    	 catch (IOException e) {
	    	      System.err.println("Error Happened: " + e);
	    	    }
    }
    	//scanner.close();
    
}