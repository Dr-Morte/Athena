package parser;

import java.util.ArrayList;

import database.Attribute;
import parser.ggParser.AttributelistContext;
import parser.ggParser.TypedattributelistContext;

public class AttributeListVisitor extends ggBaseVisitor<ArrayList<Attribute>> {
	
	@Override public ArrayList<Attribute> visitTypedattributelist(TypedattributelistContext ctx) {

		ArrayList<Attribute> arrayList = new ArrayList<>();
		for(int i = 0; i < ctx.getChildCount(); i+=3) {
			String attributeName = ctx.getChild(i).accept(new StringVisitor());
			String type = ctx.getChild(i+1).accept(new StringVisitor());
			
			Attribute typedAttribute = new Attribute (attributeName, type);
			arrayList.add(typedAttribute);
		
		}
		return arrayList;
	}
}
