package parser;

import java.util.ArrayList;
import database.Attribute;
import database.Relation;
import parser.ggParser.ClosecmdContext;
import parser.ggParser.CreatecmdContext;
import parser.ggParser.ExitcmdContext;
import parser.ggParser.InsertcmdContext;
import parser.ggParser.OpencmdContext;
import parser.ggParser.QueryContext;
import parser.ggParser.ShowcmdContext;
import parser.ggParser.WritecmdContext;
import java.util.function.Predicate;
import database.Tuple;

public class ProgramVisitor extends ggBaseVisitor<Void>{

	@Override public Void visitCreatecmd(CreatecmdContext ctx) { 
		String relationname = ctx.getChild(1).accept(new StringVisitor());
		ArrayList<Attribute> typedAttributeList = ctx.getChild(3).accept(new AttributeListVisitor());
		ArrayList<String> attributeList = ctx.getChild(7).accept(new StringlistVisitor());
		System.out.println(relationname);
		System.out.println(typedAttributeList);
		System.out.println(attributeList);

		return null; // because it not returning anything
	 }
	
	@Override public Void visitInsertcmd(InsertcmdContext ctx) { 
		
		if(ctx.getChild(2).equals("VALUES FROM")) {
			Relation relationname = ctx.getChild(1).accept(new RelationVisitor());
			String literal = ctx.getChild(1).accept(new StringVisitor());
			
		} else {
			Relation relationname = ctx.getChild(1).accept(new RelationVisitor());
			Relation expr = ctx.getChild(3).accept(new RelationVisitor());
		}	
			
		return null;
	}
	
	//might not need visitquery
	@Override public Void visitQuery(QueryContext ctx) {
		
		// it stores it as a view not saved to the desk may be you print it out and thats it. 
		// just show it thats it. 
		
		String relationname = ctx.getChild(0).accept(new StringVisitor());
		Relation expr = ctx.getChild(2).accept(new RelationVisitor()); 
		
		//may be a function that prints view of the relation to the screen 
		
		return null; 	
		
	}
	
	@Override public Void visitOpencmd(OpencmdContext ctx) 
	{ 
		Relation relationname = ctx.getChild(1).accept(new RelationVisitor());
		//open()
		return null; 
	}
	
	@Override public Void visitClosecmd(ClosecmdContext ctx) {

		Relation relationname = ctx.getChild(1).accept(new RelationVisitor());
		//close()

	 	return null;
	 }	


	@Override public Void visitWritecmd(WritecmdContext ctx) { 

		Relation relationname = ctx.getChild(1).accept(new RelationVisitor());
		//write()
		return null; 
	}

	@Override public Void visitExitcmd(ExitcmdContext ctx) { 
		// call exit()
		

		return null; 
	}
	
	@Override public Void visitDeletecmd(ggParser.DeletecmdContext ctx) //make sure func takes rel name and pred 
	{ 
		Predicate<Tuple> tup;  //predicates in java.util		
		
		String relName= ctx.getChild(1).accept(new StringVisitor());
		tup=	 ctx.getChild(3).accept(new ConditionVisitor());
		//input delete function here

		 
		return null; 
	}
	/*@Override public Void visitExitcmd(ggParser.ExitcmdContext ctx)
	{
		//calls exit command DB team has
	}*/
	@Override public Void visitShowcmd(ggParser.ShowcmdContext ctx)
	{
		Relation r =ctx.getChild(1).accept(new RelationVisitor());
		//show(r); assuming their function is called show
		return null;
	}
	@Override public Void visitUpdatecmd(ggParser.UpdatecmdContext ctx)
	{
		String relName = ctx.getChild(1).accept(new StringVisitor());
		Predicate<Tuple> pred = ctx.getChild(ctx.getChildCount()-1).accept(new ConditionVisitor());
		int count = ctx.getChildCount()-2;// dont want end condition?
		String attrName;
		String literal;
		ArrayList<String> attrNames;
		ArrayList<String> literals;
		for(int i=3;i<count; i+=2)
		{
			attrName= ctx.getChild(i).accept(new StringVisitor());
			literal= ctx.getChild(i+2).accept(new StringVisitor());
			attrNames.add(attrName);
			literals.add(literal);
		}
		//make func that takes rel name and returns its type (goes through whole table)
		Relation r = new Relation();
		for(int i=0;i<count;i++){
			if(DB.relAt(i).getName().equals(relName)
					r=DB.relAt(i);
		
		}
		//r.selectAllTuples(pred); //puts all tuples that satisfy the condition in a relation
		Relation r2 = r.selectAllTuples(pred);
		for(int i=0;i<r2.numTuples;i++)
		{
			for(int j=0;i<attrNames.length();j++)
				if(r2.getAttribute(i).equals(attrNames.at(j))==0)
				{
					r2.getLiteral(i)=literals.at(j);
				}
				
		}
		
		return null;/*
		'UPDATE' relationname 'SET' attributename '=' literal ( ',' attributename '=' literal )* 'WHERE' condition;
*/
	}

}
