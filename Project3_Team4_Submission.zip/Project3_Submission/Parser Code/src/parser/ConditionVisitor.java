package parser;

import java.util.ArrayList;
import java.util.function.Predicate;

import database.Tuple;

public class ConditionVisitor extends ggBaseVisitor<Predicate<Tuple>> {
	@Override public Predicate<Tuple> visitCondition(ggParser.ConditionContext ctx)
	{
		ArrayList<Predicate<Tuple>> tList = new ArrayList<>();
		for(int i=0;i<ctx.getChildCount();i+=2)
		{
			tList.add(visit(ctx.getChild(i)));
		}
		return t-> {             //if one statement is true the whole thing true
			for(Predicate<Tuple> predicate: tList)
			{
				if(predicate.test(t))
					return true;
			}
			return false;
		};
	}
	@Override public Predicate<Tuple> visitConjunction(ggParser.ConjunctionContext ctx)
	{
		ArrayList<Predicate<Tuple>> tList2 = new ArrayList<>();
		for(int i=0;i<ctx.getChildCount();i+=2)
		{
			tList2.add(visit(ctx.getChild(i)));
		}
		return t-> {             //if one false whole thing false
			for(Predicate<Tuple> predicate2: tList2)
			{
				if(predicate2.test(t)==false)
					return false;
			}
			return true;
		};
	}
	@Override public Predicate<Tuple> visitComparison(ggParser.ComparisonContext ctx)
	{
		if(ctx.getChild(0).getText().equals( "(" ))
			return visit(ctx.getChild(1)); //visit is in antlr
		Operand lhs;
		Operand rhs;
		lhs =ctx.getChild(0).accept(new ChildOperand());
		rhs =ctx.getChild(0).accept(new ChildOperand());
		if(ctx.getChild(1).getText().equals(">"))
			return t->lhs.eval(t).compareTo(rhs.eval(t)) > 0;
		if(ctx.getChild(1).getText().equals("<"))
			return t->lhs.eval(t).compareTo(rhs.eval(t)) < 0;
		if(ctx.getChild(1).getText().equals(">="))
			return t->lhs.eval(t).compareTo(rhs.eval(t)) >= 0;
		if(ctx.getChild(1).getText().equals("<="))
			return t->lhs.eval(t).compareTo(rhs.eval(t)) <= 0;
		if(ctx.getChild(1).getText().equals("=="))
			return t->lhs.eval(t).compareTo(rhs.eval(t)) == 0;
		if(ctx.getChild(1).getText().equals("!="))
			return t->lhs.eval(t).compareTo(rhs.eval(t)) != 0;
		else
		{
			System.out.println("error: invalid comparison");
			return null;	
		}
	}

}
