package parser;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

import database.Literal;

public class ChildOperand extends ggBaseVisitor<Operand>
{

	@Override public Operand visitOperand(ggParser.OperandContext ctx)
	{
		return visit(ctx.getChild(0));
	}
	@Override public Operand visitAttributename(ggParser.AttributenameContext ctx)
	{
		
		String attrName=ctx.getChild(0).accept(new StringVisitor());
		return (t->t.get(attrName));
	}
	
	@Override public Operand visitLiteral(ggParser.LiteralContext ctx)
	{
		Literal literal = new Literal(ctx.getChild(0).getText());
		return (t->literal);
	}
}
