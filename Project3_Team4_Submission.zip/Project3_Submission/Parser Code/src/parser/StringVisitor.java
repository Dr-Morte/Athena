package parser;

import parser.ggParser.AttributenameContext;
import parser.ggParser.IdentifierContext;
import parser.ggParser.LiteralContext;
import parser.ggParser.RelationnameContext;
import parser.ggParser.TypeContext;

public class StringVisitor extends ggBaseVisitor<String> {
	
	//
	@Override public String visitIdentifier(IdentifierContext ctx) { 
		String identifier = "";
		for(int i = 0; i < ctx.getChildCount(); i++) {
			identifier += ctx.getChild(i).getText();
		}
		return identifier; 
		
	}
	
	@Override public String visitAttributename(AttributenameContext ctx) {
		
		return visit(ctx.getChild(0));
	}
	
	//type needs to be a string in the database conform to place holders
	@Override public String visitType(TypeContext ctx) {
		String type = "";
		for(int i = 0; i < ctx.getChildCount(); i++) {
			type += ctx.getChild(i).getText();
		}
		return type;
		
	}
	
	@Override public String visitRelationname(RelationnameContext ctx) {
		
		return visit(ctx.getChild(0));
		
	}
	
	@Override public String visitLiteral(LiteralContext ctx) {
		
		return ctx.getChild(0).getText();	
	}
	
}
