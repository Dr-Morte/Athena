package parser;

import database.Literal;
import database.Tuple;

public interface Operand {
	public Literal eval(Tuple t);
}
