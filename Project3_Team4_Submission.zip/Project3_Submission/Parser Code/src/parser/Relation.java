package parser;

import java.util.ArrayList;
import java.util.function.Predicate;

import database.Tuple;

public class Relation 
{
	String name;
	ArrayList<Tuple> rows;
	public String getName(){
		return name;
	}
	private void addTuple(Tuple t)
	{
		
	}
	public Relation selectAllTuples (Predicate<Tuple> predicate)
	{
		Relation r = new Relation();
		for (Tuple t : rows) 
		{
			if (predicate.test(t))
					r.addTuple(t);
		}
		return r;
	}
}
