package parser;

import java.util.ArrayList;
import parser.ggParser.AttributelistContext;

public class StringlistVisitor extends ggBaseVisitor<ArrayList<String>> {
	
	@Override
	public ArrayList<String> visitAttributelist(AttributelistContext ctx){
		
		ArrayList<String> arrayString = new ArrayList<>();
		
		for(int i = 0; i < ctx.getChildCount(); i += 2){
			String str = ctx.getChild(i).accept(new StringVisitor());
			arrayString.add(str);
		}
		
		return arrayString;
	}
}
