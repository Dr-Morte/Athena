import java.util.Scanner;

public class Interface {
	
	public static void userInterface() {
		Database Database = new Database();		// Creates a Database to store the relations in a ArrayList of Relations
		String userInput;						// Initialize variables
		//String userInputTwo;
		//int userInputThree;
		Scanner sOne = new Scanner(System.in);	// Initialize Scanner to take in user input
		
		System.out.println("Menu:");
		printMenu();
		System.out.println("What would you like to do?: ");
		userInput = sOne.nextLine();
		do {
			
			// Creates a new Relation
			// the new relation is pushed to a list of Relations
			// the user must keep track of the order the relations are added to used them later
			// they are called by the number in the Database list they are added STARTING WITH ONE!
			// Example: if you want to use the second Relation you created, when prompted, enter 2 to modify that relation
			if(userInput.equals("createRelation")) {
				System.out.println("How Many Tuples?: ");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				Database.addRelation(new Relation(userInputInt));
				// Fills the attributes for the new Relation
				System.out.println("How Many Attributes?: ");		
				int userInputIntTwo = sOne.nextInt();
				sOne.nextLine();								
				for(int i = 0; i < userInputIntTwo; ++i) {				
					System.out.println("Enter an Attribute:");		
					String userInputTwo = sOne.nextLine();
					Database.getRelationAt(Database.numRelations()-1).addAttribute(userInputTwo);
				}
				// Fills the tuples for the new Relation
				for(int i = 0; i < Database.getRelationAt(Database.numRelations()-1).numTuples; ++i) {
					System.out.println("Row " + (i + 1) + ": ");
					for (int j = 0; j < Database.getRelationAt(Database.numRelations()-1).numAttributes; ++j) {
						System.out.println("Enter Data at column " + (j + 1) + ":");
						String userInputTwo = sOne.nextLine();
						
						Database.getRelationAt(Database.numRelations()-1).setData(i, j, userInputTwo);
					}
				}
			}
			// add new tuple to an existing relation and fill the row
			if(userInput.equals("addTuple")) {
				System.out.println("Enter Relation Number to add to:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				Database.getRelationAt(userInputInt - 1).addTuple();
				// fills the new tuple
				for (int i = 0; i < Database.getRelationAt(Database.numRelations()-1).numAttributes; ++i) {
					System.out.println("Enter Data at column " + (i + 1) + ":");
					String userInputTwo = sOne.nextLine();
					int row = Database.getRelationAt(userInputInt - 1).numTuples - 1;
					Database.getRelationAt(Database.numRelations()-1).setData(row, i, userInputTwo);
				}	
			}
			// Add a new attribute and fill the new column
			if (userInput.equals("addAttribute")) {
				System.out.println("Enter Relation Number to add to:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter Attribute:");
				String userInputString = sOne.nextLine();
				Database.getRelationAt(userInputInt - 1).addAttribute(userInputString);
				
				for (int i = 0; i < Database.getRelationAt(userInputInt - 1).numTuples; ++i) {
					System.out.println("Enter New Attribute Data at Row " + (i + 1));
					String userInputTwo = sOne.nextLine();
					int column = Database.getRelationAt(userInputInt - 1).numAttributes - 1;
					Database.getRelationAt(Database.numRelations()-1).setData(i, column, userInputTwo);
				}
			}
			// Delete a Tuple at row number
			if (userInput.equals("deleteTuple")) {
				System.out.println("Enter Relation Number to modify:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter row number to delete:");
				int userInputIntTwo = sOne.nextInt();
				sOne.nextLine();
				Database.getRelationAt(userInputInt - 1).deleteTuple(userInputIntTwo);
			}
			// selection: gets all tuples with a common attribute form a Relation
			if(userInput.equals("selection")) {
				System.out.println("Enter Relation Number:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter Attribute to select:");
				String userInputTwo = sOne.nextLine();
				
				Database.getRelationAt(userInputInt-1).selection(userInputTwo).printRelation();
			}
			// projection: gets all members with in an attribute column form a Relation
			if(userInput.equals("projection")) {
				System.out.println("Enter Relation Number:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter Attribute to select:");
				String userInputTwo = sOne.nextLine();
				
				System.out.println(Database.getRelationAt(userInputInt-1).projection(userInputTwo));
			}
			// Rename an Attribute of a relation at a single column
			if(userInput.equals("renameAttribute")) {
				System.out.println("Enter Relation Number:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter Attribute number to rename:");	// starting at ONE
				int userInputIntTwo = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter Attribute's New Name:");
				String userInputTwo = sOne.nextLine();
				
				Database.getRelationAt(userInputInt).updateAttribute(userInputIntTwo-1, userInputTwo);
				System.out.println("Updated Relation:");
				Database.getRelationAt(userInputInt).printRelation();
			}
			// Set Union for two relations
			if(userInput.equals("setUnion")) {
				System.out.println("Enter first Relation Numbe:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter second Relation Numbe:");
				int userInputIntTwo = sOne.nextInt();
				sOne.nextLine();
				
				Database.setUnion(Database.getRelationAt(userInputInt-1), Database.getRelationAt(userInputIntTwo-1)).printRelation();
			}
			// Set Difference for two relations
			if(userInput.equals("setDifference")) {
				System.out.println("Enter first Relation Numbe:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter second Relation Numbe:");
				int userInputIntTwo = sOne.nextInt();
				sOne.nextLine();
				
				Database.setDiff(Database.getRelationAt(userInputInt-1), Database.getRelationAt(userInputIntTwo-1)).printRelation();
			}
			// Natural Join two relations
			if(userInput.equals("naturalJoin")) {
				System.out.println("Enter first Relation Numbe:");
				int userInputInt = sOne.nextInt();
				sOne.nextLine();
				System.out.println("Enter second Relation Numbe:");
				int userInputIntTwo = sOne.nextInt();
				sOne.nextLine();
				
				Database.getRelationAt(userInputInt-1).naturalJoin(Database.getRelationAt(userInputIntTwo-1));
				Database.getRelationAt(userInputInt-1).printRelation();
			}
			
			// Prints a relation
			if (userInput.equals("printRelation")) {
				System.out.println("Enter the Relation Number");
				int userInputInt = sOne.nextInt() - 1;
				sOne.nextLine();
				Database.getRelationAt(userInputInt).printRelation();
			}
			// prints all relations
			if (userInput.equals("printDatabase")) {
				for(int i = 0; i < Database.numRelations(); ++i) {
					Database.getRelationAt(i).printRelation();
				}
			}
			// prints the menu
			if(userInput.equals("menu")) {
				printMenu();
			}
			System.out.println("What would you like to do?: ");
			userInput = sOne.nextLine();
		} while (!userInput.equals("exit")); 
		sOne.close();
		System.out.println("Goodbye");
	}
	
	public static void printMenu() {
		System.out.println("Camands:");
		System.out.println("(createTable), (addTuple), (addAttribute), (deleteTuple), (printRelation), \n"
				+ "(printDatabase), (selection), (projection), (renameAttribute), (setUnion), (setDifference), (naturalJoin), (menu), (exit)");
	}
}
