import java.util.*;
public class Tuple {
	
	public String name;
	public ArrayList<String> tuple;
	
	public Tuple() {
		this.tuple = new ArrayList<String>();
		this.name = "Empty";
		
	}
	public String getName() {
		return name;
	}
	public int getSize() {
		return tuple.size();
	}
	public String getDataAt(int index) {
		return tuple.get(index);
	}
	public void setName(String newName) {
		this.name = newName;
	}
	public ArrayList<String> getTuple(){
		return tuple;
	}
	public void setDataMemberAtColumn(int column, String data) {
		tuple.set(column, data);
	}
	public void addNewDataMember(String data) {
		tuple.add(data);
	}
	public void updataTuple(ArrayList<String> dataString) {
		this.tuple = dataString;
	}
	public void deleteMemberAt(int index) {
		tuple.remove(index);
	}
	
	
}