import java.util.*;
public class BuildDatabase {
	
	public static void build() {
		
		String[] listOne = {"NEW_CRN", "NEW_Subj", "NEW_Crse", "NEW_Sec", "NEW_Cred", "NEW_Title", "NEW_Days", "NEW_Time", "NEW_Cap",
				"NEW_Act", "NEW_Rem", "NEW_Instructor", "NEW_Date (MM/DD)", "NEW_Location", "NEW_Attribute"};
		String[] listTwo = {"CRN", "Subj", "Crse", "Sec", "Cred", "Title", "Days", "Time", "Cap",
				"Act", "Rem", "Instructor", "Date (MM/DD)", "Location", "Attribute"};
		
		ArrayList<String> AListOne = new ArrayList<String>();
		ArrayList<String> AListTwo = new ArrayList<String>();
		
		for (int i = 0; i < 15; i++) {
			AListOne.add(listOne[i]);
		}
		for (int i = 0; i < 15; i++) {
			AListTwo.add(listTwo[i]);
		}
		
		Relation t = new Relation(6);		// create table with 6 tuples
		Relation s = new Relation(6);		// create table with 6 tuples
		
		Database d = new Database();
		d.addRelation(t);
		d.addRelation(s);
		
		// insert the Attributes
		t.addAttribute("CRN");
		t.addAttribute("Subj");
		t.addAttribute("Crse");
		t.addAttribute("Sec");
		t.addAttribute("Cred");
		t.addAttribute("Title");
		t.addAttribute("Days");
		t.addAttribute("Time");
		t.addAttribute("Cap");
		t.addAttribute("Act");
		t.addAttribute("Rem");
		t.addAttribute("Instructor");
		t.addAttribute("Date (MM/DD)");
		t.addAttribute("Location");
		t.addAttribute("Attribute");
		// insert the data
		//t.row1
		t.setData(0,0,"10001");
		t.setData(0, 1, "ACCT");
		t.setData(0, 2, "209");
		t.setData(0, 3, "501");
		t.setData(0, 4, "3");
		t.setData(0, 5, "survey of acct prin");
		t.setData(0, 6, "T");
		t.setData(0, 7, "8:00am-9:15am");
		t.setData(0, 8, "430");
		t.setData(0, 9, "430");
		t.setData(0, 10, "0");
		t.setData(0, 11, "Mary Stansny");
		t.setData(0, 12, "08/28-12/13");
		t.setData(0, 13, "WCBA 113");
		t.setData(0, 14, "TBA");

		//t.row2
		t.setData(1, 0, "10003");
		t.setData(1, 1, "ACCT");
		t.setData(1, 2, "229");
		t.setData(1, 3, "201");
		t.setData(1, 4, "3");
		t.setData(1, 5, "HNR-INTRO ACCOUNTING");
		t.setData(1, 6, "TR");
		t.setData(1, 7, "9:35am-10:50am");
		t.setData(1, 8, "0");
		t.setData(1, 9, "19");
		t.setData(1, 10, "-19");
		t.setData(1, 11, "James Benjamin");
		t.setData(1, 12, "8/28-12/13");
		t.setData(1, 13, "WCBA");
		t.setData(1, 14, "TBA");
		//row3
		t.setData(2, 0, "27160");
		t.setData(2, 1, "ACCT");
		t.setData(2, 2, "210");
		t.setData(2, 3, "502");
		t.setData(2, 4, "3");
		t.setData(2, 5, "MGRL & COST ACCT PRIN");
		t.setData(2, 6, "TR");
		t.setData(2, 7, "11:10am-12:25pm");
		t.setData(2, 8, "58");
		t.setData(2, 9, "58");
		t.setData(2, 10, "0");
		t.setData(2, 11, "Robert Strawser");
		t.setData(2, 12, "08/28-12/13");
		t.setData(2, 13, "WCBA 114");
		t.setData(2, 14, "TBA");
		//t.row4
		t.setData(3, 0, "10005");
		t.setData(3, 1, "ACCT");
		t.setData(3, 2, "229");
		t.setData(3, 3, "501");
		t.setData(3, 4, "3");
		t.setData(3, 5, "INTRO ACCOUNTING");
		t.setData(3, 6, "MW");
		t.setData(3, 7, "8:00am-9:15am");
		t.setData(3, 8, "44");
		t.setData(3, 9, "2");
		t.setData(3, 10, "0");
		t.setData(3, 11, "Jeannie Bar");
		t.setData(3, 12, "08/28-12/13");
		t.setData(3, 13, "WCBA 104");
		t.setData(3, 14, "TBA");
		//row5
		t.setData(4, 0, "10002");
		t.setData(4, 1, "ACCT");
		t.setData(4, 2, "209");
		t.setData(4, 3, "502");
		t.setData(4, 4, "3");
		t.setData(4, 5, "SURVEY OF ACCT PRIN");
		t.setData(4, 6, "R");
		t.setData(4, 7, "08:00 am-09:15 am");
		t.setData(4, 8, "430");
		t.setData(4, 9, "430");
		t.setData(4, 10, "0");
		t.setData(4, 11, "Mary K.Stasny");
		t.setData(4, 12, "08/28-12/13");
		t.setData(4, 13, "WCBA 113");
		t.setData(4, 14, "TBA");
		//row6
		t.setData(5, 0, "10004");
		t.setData(5, 1, "ACCT");
		t.setData(5, 2, "229");
		t.setData(5, 3, "202");
		t.setData(5, 4, "3");
		t.setData(5, 5, "HNR-INTRO ACCOUNTING");
		t.setData(5, 6, "R");
		t.setData(5, 7, "03:00 pm-05:30 pm");
		t.setData(5, 8, "0");
		t.setData(5, 9, "8");
		t.setData(5, 10, "-8");
		t.setData(5, 11, "Jerry R.Strawser");
		t.setData(5, 12, "08/28-12/13");
		t.setData(5, 13, "WCBA 290");
		t.setData(5, 14, "TBA");
	
		s.addAttribute("CRN");
		s.addAttribute("Subj");
		s.addAttribute("Crse");
		s.addAttribute("Sec");
		s.addAttribute("Cred");
		s.addAttribute("Title");
		s.addAttribute("Days");
		s.addAttribute("Time");
		s.addAttribute("Cap");
		s.addAttribute("Act");
		s.addAttribute("Rem");
		s.addAttribute("Instructor");
		s.addAttribute("Date (MM/DD)");
		s.addAttribute("Location");
		s.addAttribute("Attribute");
		//row1
		s.setData(0, 0,"31232");
		s.setData(0, 1, "AERO");
		s.setData(0, 2, "201");
		s.setData(0, 3, "505");
		s.setData(0, 4, "3");
		s.setData(0, 5, "INTRO TO FLIGHT");
		s.setData(0, 6, "TR");
		s.setData(0, 7, "9:35 am-10:50 am");
		s.setData(0, 8, "45");
		s.setData(0, 9, "3");
		s.setData(0, 10, "42");
		s.setData(0, 11, "Thomas Strganac");
		s.setData(0, 12, "08/28-12/13");
		s.setData(0, 13, "HRBB 131");
		s.setData(0, 14, "TBA");
		//row2
		s.setData(1, 0,"29316");
		s.setData(1, 1, "AERO");
		s.setData(1, 2, "201");
		s.setData(1, 3, "502");
		s.setData(1, 4, "3");
		s.setData(1, 5, "INTRO TO FLIGHT");
		s.setData(1, 6, "TR");
		s.setData(1, 7, "02:20 pm-03:35 pm");
		s.setData(1, 8, "45");
		s.setData(1, 9, "5");
		s.setData(1, 10, "40");
		s.setData(1, 11, "Thomas Strganac");
		s.setData(1, 12, "08/28-12/13");
		s.setData(1, 13, "HRBB 131");
		s.setData(1, 14, "TBA");
		//row3
		s.setData(2, 0,"29866");
		s.setData(2, 1, "AERO");
		s.setData(2, 2, "212");
		s.setData(2, 3, "234");
		s.setData(2, 4, "3");
		s.setData(2, 5, "INTRO TO AEROTHERMODYNM");
		s.setData(2, 6, "MWF");
		s.setData(2, 7, "01:50 pm-02:40 pm");
		s.setData(2, 8, "5");
		s.setData(2, 9, "1");
		s.setData(2, 10, "4");
		s.setData(2, 11, "Adonios Karpetis");
		s.setData(2, 12, "08/28-12/13");
		s.setData(2, 13, "HRBB 131");
		s.setData(2, 14, "TBA");
		//row4
		s.setData(3, 0,"10042");
		s.setData(3, 1, "AERO");
		s.setData(3, 2, "212");
		s.setData(3, 3, "500");
		s.setData(3, 4, "3");
		s.setData(3, 5, "INTRO TO AEROTHERMODYNM");
		s.setData(3, 6, "MWF");
		s.setData(3, 7, "12:40 pm-01:30 pm");
		s.setData(3, 8, "55");
		s.setData(3, 9, "12");
		s.setData(3, 10, "43");
		s.setData(3, 11, "Kentaro Hara");
		s.setData(3, 12, "08/28-12/13");
		s.setData(3, 13, "HRBB 124");
		s.setData(3, 14, "TBA");
		//row5
		s.setData(4, 0,"23337");
		s.setData(4, 1, "AERO");
		s.setData(4, 2, "212");
		s.setData(4, 3, "501");
		s.setData(4, 4, "3");
		s.setData(4, 5, "INTRO TO AEROTHERMODYNM");
		s.setData(4, 6, "MWF");
		s.setData(4, 7, "12:40 pm-01:30 pm");
		s.setData(4, 8, "50");
		s.setData(4, 9, "4");
		s.setData(4, 10, "46");
		s.setData(4, 11, "Adonios Karpetis");
		s.setData(4, 12, "08/28-12/13");
		s.setData(4, 13, "HRBB 131");
		s.setData(4, 14, "TBA");
		//row6
		s.setData(5, 0,"24716");
		s.setData(5, 1, "AERO");
		s.setData(5, 2, "214");
		s.setData(5, 3, "200");
		s.setData(5, 4, "3");
		s.setData(5, 5, "HNR-INTRO MECH OF MATLS");
		s.setData(5, 6, "MW");
		s.setData(5, 7, "04:10 pm-05:00 pm");
		s.setData(5, 8, "4");
		s.setData(5, 9, "2");
		s.setData(5, 10, "2");
		s.setData(5, 11, "Mohammad Naraghi");
		s.setData(5, 12, "08/28-12/13");
		s.setData(5, 13, "CHEN 104");
		s.setData(5, 14, "TBA");
		
		System.out.println("Table 1");
		t.printRelation();
		System.out.println("Table 2");
		s.printRelation();
		
		System.out.println("Select Tuples with class (HNR-INTRO ACCOUNTING) in Table 1");
		t.selection("HNR-INTRO ACCOUNTING").printRelation();
		
		System.out.println("Project all CRN's in Table 2");
		System.out.println(s.projection("CRN"));
		System.out.println();
		
		System.out.println("Rename first Attribute in Table 1");
		t.updateAttribute(0, "NEW_CRN");
		t.printRelation();
		t.updateAttribute(0, "CRN");
		
		System.out.println("Rename ALL Attributes in Table 1");
		t.updateAttributeList(AListOne);
		t.printRelation();
		t.updateAttributeList(AListTwo);
		
		System.out.println("Set Union for Table 1 and 2");
		Database.setUnion(t, s).printRelation();
		
		System.out.println("Set Difference for Table 1 and 2");
		Database.setDiff(t, s).printRelation();
		
		System.out.println("Natural Join for Table 1 and 2\n");
		System.out.println("New Table 1");
		t.naturalJoin(s);
		t.printRelation();
		
	}
}
