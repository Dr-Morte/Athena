import java.util.*;
public class Attribute {

	public String name;
	//public String type;
	
	public Attribute(){
		this.name = "default";
		//this.type = "default_type";
	}
	public Attribute(String name){
		this.name = name;
		//this.type = type;
	}
	public Attribute(Attribute attribute){
		this.name = attribute.name;
		//this.type = attribute.type;
	}
	public String getName(){
		return name;
	}
	/*
	public String getType(){
		return type;
	}
	*/
	public void setName(String newName){
		this.name = newName;
	}
	/*
	public void setType(String type){
		this.type = type;
	}
	*/
	
}
