import java.util.*;
public class Relation {
	
	public int numAttributes;
	public int numTuples;
	
	public ArrayList<Attribute> attributeList;
	public ArrayList<Tuple> tuples;
	
	public Relation() {
		this.numAttributes = 0;
		this.numTuples = 0;
		this.attributeList = new ArrayList<Attribute>();
		this.tuples = new ArrayList<Tuple>();
	}
	// Used when making table in the main, takes in number of tuples
	public Relation(int numTup){
		this.numAttributes = 0;
		this.numTuples = numTup;
		this.attributeList = new ArrayList<Attribute>();
		this.tuples = new ArrayList<Tuple>();
	}
	// Copy constructor
	public Relation(Relation t) {
		this.numAttributes = t.numAttributes;
		this.numTuples = t.numTuples;
		this.attributeList = t.attributeList;
		this.tuples = t.tuples;
	}
	// prints a tuple
	public void printTuple(int x){
		System.out.print(tuples.get(x).getTuple() + " ");
		System.out.println();
	}
	public void printRelation(){
		for(int i = 0; i < numAttributes; i++){
			System.out.print(this.attributeList.get(i).getName() + " ");
		}
		System.out.println();
		for(int i = 0; i < numTuples; i++){
			this.printTuple(i);
		}
		System.out.println();
	}
	
	public void insertTuple(ArrayList<String> newTuple) {
		this.addTuple();
		
		for(int i = 0; i < numAttributes; ++i) {
			setData(numTuples - 1, i, newTuple.get(i));
		}
	}
	
	public void deleteTuple(int index) {
		tuples.remove(index);
	}
	
	// change an existing attribute
	public void updateAttribute(int pos, String att/*, String type*/){
		this.attributeList.get(pos).setName(att);
		//this.attributeList.get(pos).setType(type);
	}
	// Updates all Attribute names
	public void updateAttributeList(ArrayList<String> newList) {
		for(int i = 0; i < numAttributes; ++i) {
			this.attributeList.get(i).setName(newList.get(i));
		}
	}
	// creates a new attribute and respective column
	public void addAttribute(String att){
		numAttributes = numAttributes + 1;
		
		attributeList.add(new Attribute());
		
		attributeList.get(attributeList.size()-1).setName(att);
		//attributeList.get(attributeList.size()-1).setType(type);
		
		for(int i = 0; i < numTuples; i++){
			tuples.add(new Tuple());
			tuples.get(i).addNewDataMember("Empty");
		}
	}
	// assigns STRING data to existing data position
	public void setData(int row, int column, String data){
		tuples.get(row).setDataMemberAtColumn(column, data);
	}
	
	// Creates a new Unfilled tuple
	public void addTuple(){
		numTuples = numTuples + 1;
		tuples.add(new Tuple());
		for(int i = 0; i < numAttributes; i++){
			tuples.get(numTuples - 1).addNewDataMember("Empty");
		}
	}
	
	public ArrayList<String> returnTuple(int row) {
		return tuples.get(row).getTuple();
	}
	public void mergeTuples(Relation relation, int relationOneRowNum, int relationTwoRowNum){
		
		boolean found;
		for(int i = 0; i < relation.attributeList.size(); i++){
			found = false;
			for(int j = 0; j < numAttributes; j++){
				if(relation.attributeList.get(i).getName().equals(attributeList.get(j).getName())){
					//setData(j, tupleOne, relation.tuples.get(i).get(tupleTwo));
					found = true;
				}
			}
			if(!found){
				addAttribute(relation.attributeList.get(i).getName()/*, relation.attributeList.get(i).getType()*/);
				setData(relationOneRowNum, numAttributes - 1, relation.tuples.get(relationTwoRowNum).getDataAt(i));
			}
		}
	}
	
	// Imports a tuple from an existing table
	public void importTuple(Relation relation, int rowNum){
		this.addTuple();
		boolean found;
		for(int i = 0; i < relation.attributeList.size(); i++){
			found = false;
			for(int j = 0; j < numAttributes; j++){
				if(relation.attributeList.get(i).getName().equals(attributeList.get(j).getName())){
					setData(numTuples -1, j,relation.tuples.get(rowNum).getDataAt(i));
					found = true;
				}
			}
			if(!found){
				addAttribute(relation.attributeList.get(i).getName()/*, relation.attributeList.get(i).getType()*/);
				setData(numTuples -1, numAttributes - 1, relation.tuples.get(rowNum).getDataAt(i));
			}
		}
	}
	// Returns a Table of tuples with a common condition
	public Relation selection(String condition) {
		Relation newTable = new Relation();
		for(int i = 0; i < numTuples; i++) {
			for(int j = 0; j < numAttributes; j++) {
				if(tuples.get(i).getDataAt(j).equals(condition)) {
					newTable.importTuple(this, i);
				}
			}
		}
		return newTable;
	}
	
	public ArrayList<String> projection(String attribute) {
		ArrayList<String> list = new ArrayList<String>();
		for(int i = 0; i < numAttributes; i++) {
			if(attributeList.get(i).getName().equals(attribute)){
				for(int j = 0; j < numTuples; ++j) {
					list.add(tuples.get(j).getDataAt(i));
				}
			}
		}
		return list;
	}
	
	public void naturalJoin(Relation relation) {
		for(int i = 0; i < relation.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < numTuples; ++j) {
				if(relation.tuples.get(i).getDataAt(0).equals(tuples.get(j).getDataAt(0))) {
					this.mergeTuples(relation, j, i);
					found = true;
				}
			}
			if(!found) {
				importTuple(relation, i);
			}
		}
	}
	
}