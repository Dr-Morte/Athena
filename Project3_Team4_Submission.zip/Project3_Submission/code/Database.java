import java.util.*;
public class Database {
	
	public ArrayList<Relation> relationList;
	
	public Database() {
		this.relationList = new ArrayList<Relation>();
	}
	public void addRelation(Relation relation) {
		relationList.add(relation);
	}
	public void printDatabase() {
		for(int i = 0; i < relationList.size(); ++i) {
			relationList.get(i).printRelation();
		}
	}
	public Relation getRelationAt(int index) {
		return relationList.get(index);
	}
	public int numRelations() {
		return relationList.size();
	}
	
	// Calculates the Union of two relations and returns a new relation
	public static Relation setUnion(Relation tableOne, Relation tableTwo) {
		Relation newTable = new Relation();
		
		for(int i = 0; i < tableOne.numTuples; ++i) {
			newTable.importTuple(tableOne, i);
		}
		
		for(int i = 0; i < tableTwo.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < newTable.numTuples; ++j) {
				if(tableTwo.tuples.get(i).getDataAt(0).equals(newTable.tuples.get(j).getDataAt(0))) {
					found = true;
				}
			}
			if (!found) {
				newTable.importTuple(tableTwo, i);
			}
		}
		return newTable;
	}
	// Calculates the Difference of two relations and returns a new relation
	public static Relation setDiff(Relation tableOne, Relation tableTwo) {
		Relation newTable = new Relation();
		
		for(int i = 0; i < tableOne.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < tableTwo.numTuples; ++j) {
				if(tableOne.tuples.get(i).getDataAt(0).equals(tableTwo.tuples.get(j).getDataAt(0))) {
					found = true;
				}
			}
			if (!found) {
				newTable.importTuple(tableOne, i);
			}
		}
		for(int i = 0; i < tableTwo.numTuples; ++i) {
			boolean found = false;
			for(int j = 0; j < tableOne.numTuples; ++j) {
				if(tableTwo.tuples.get(i).getDataAt(0).equals(tableOne.tuples.get(j).getDataAt(0))) {
					found = true;
				}
			}
			if (!found) {
				newTable.importTuple(tableTwo, i);
			}
		}
		return newTable;
	}
	
	public static Relation crossProduct(Relation tableOne, Relation tableTwo) {
		 int newNumAtt = tableOne.numAttributes + tableTwo.numAttributes;
		 
		 ArrayList<Attribute> newAttributes = new ArrayList<Attribute>();
		//setting up newTable
		for ( int i = 0; i < tableOne.numAttributes; i++){
			newAttributes.add(tableOne.attributeList.get(i));
		}
		for ( int i = 0; i < tableTwo.numAttributes; i++){
			newAttributes.add(tableTwo.attributeList.get(i));
		}
		// Create new relation
		Relation newTable = new Relation();
		newTable.numAttributes = newNumAtt;
		
		newTable.attributeList = newAttributes;
		
		ArrayList<String> row1 = new ArrayList<String>();
		ArrayList<String> row2 = new ArrayList<String>();
		ArrayList<String> newRow = new ArrayList<String>();
		
		for(int i = 0; i < tableOne.numTuples; ++i) {					// for each row in table 1
			row1 = tableOne.tuples.get(i).getTuple();
			newRow = row1;			
			for(int j = 0; j < tableTwo.numTuples; j++) {
				row2 = tableTwo.tuples.get(j).getTuple();
				for (int k = 0; k < tableTwo.numAttributes; ++k) {
					newRow.add(row2.get(k));
				}
				newTable.insertTuple(newRow);
			}
		}
		return newTable;
	}
	
}