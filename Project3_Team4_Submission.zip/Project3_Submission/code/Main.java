
public class Main {
	
	public static void main(String[] args) {
		
		
		//Uncomment "BuildDatabase.build();"
		//to run the pre-implemented schedule code
		//for to demo functions
		
		
		
		//BuildDatabase.build();						// UNCOMMENT HERE
		
		
		
		//Uncomment "Interface.userInterface();"
		//to run the user interface						// DO NOT UNCOMMENT BOTH
		//to demo the "pseudo parser"
		
		
		
		
		//Interface.userInterface();					// UNCOMMENT HERE
		
		
	}
}
